import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import umap
from sentence_transformers import SentenceTransformer

# 1. Carregar o dataset
df_full = pd.read_csv("BerTinbau_Sentiment_fine_tunning_filtrado.csv")  

#aspectos_desejados = ['Pontualidade', 'Organização']
aspectos_desejados = ['Colaboração','Comunicação eficaz','Autoconfiança','Autonomia','Pontualidade','Conhecimentos Técnicos','Qualidade das entregas','Adaptabilidade','Gestão do tempo', 'Proatividade', 'Resiliência', 'Empatia', 'Inovação e Criatividade', 'Organização', 'Relacionamento interpessoal']
df_filtrado = df_full[df_full['aspecto'].isin(aspectos_desejados)]

# Separar os dados
df_neg = df_filtrado[df_filtrado['sentimento'] == 'Negativo']
df_pos = df_filtrado[df_filtrado['sentimento'] == 'Positivo']

df = df_full

# 2. Carregar o modelo SBERT
#model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
model = SentenceTransformer('sentence-transformers/paraphrase-multilingual-mpnet-base-v2')  


# 3. Gerar embeddings para os feedbacks
feedbacks = df['feedback'].astype(str).tolist()
embeddings = model.encode(feedbacks, show_progress_bar=True)

# 4. Reduzir com UMAP
reducer = umap.UMAP(n_neighbors=15, min_dist=0.1, metric='cosine', random_state=42)
reduced = reducer.fit_transform(embeddings)

# 5. Adicionar ao dataframe
df['x'] = reduced[:, 0]
df['y'] = reduced[:, 1]

# 6. Plotar com Seaborn
plt.figure(figsize=(12, 8))
sns.scatterplot(data=df, x='x', y='y', hue='aspecto', palette='tab20', s=80, alpha=0.8)
plt.title('Visualização de Similaridade entre Feedbacks por Aspecto')
plt.xlabel('UMAP-1')
plt.ylabel('UMAP-2')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

