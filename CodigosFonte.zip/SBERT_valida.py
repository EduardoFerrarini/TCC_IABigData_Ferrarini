import csv
from collections import defaultdict

arquivo = 'Aspect_Classification_fine_tunning.csv'

contagem = defaultdict(lambda: {'0': 0, '1': 0})
# Agora armazena (frase.lower(), label) para cada aspecto
feedbacks_por_aspecto_label = defaultdict(set)
duplicados = []

with open(arquivo, encoding='utf-8') as f:
    for line_num, line in enumerate(f):
        line = line.strip()
        if line_num == 0 or not line:
            continue
        # 1) label: último campo após a última vírgula
        idx_last_comma = line.rfind(',')
        if idx_last_comma == -1:
            continue
        label = line[idx_last_comma+1:].strip().replace('"', '')
        restante = line[:idx_last_comma]
        # 2) aspecto: entre a penúltima e última vírgula
        idx_penultimate_comma = restante.rfind(',')
        if idx_penultimate_comma == -1:
            continue
        aspecto = restante[idx_penultimate_comma+1:].strip().replace('"', '')
        frase = restante[:idx_penultimate_comma].strip().replace('"', '')
        if label in ('0', '1'):
            contagem[aspecto][label] += 1
            # Verifica duplicidade considerando aspecto e label
            key = (frase.lower(), label)
            if key in feedbacks_por_aspecto_label[aspecto]:
                duplicados.append((frase, aspecto, label))
            else:
                feedbacks_por_aspecto_label[aspecto].add(key)

print(f"{'Aspecto':40} | Label 0 | Label 1 | Igual quantidade? | Diferença para igualar")
print('-'*90)
for aspecto, counts in contagem.items():
    iguais = 'SIM' if counts['0'] == counts['1'] else 'NÃO'
    diff = abs(counts['0'] - counts['1'])
    print(f"{aspecto:40} | {counts['0']:7} | {counts['1']:7} | {iguais:16} | {diff:20}")

if duplicados:
    print("\nFeedbacks idênticos encontrados para o mesmo aspecto e mesmo label:")
    for frase, aspecto, label in duplicados:
        print(f"- '{frase}' | Aspecto: {aspecto} | Label: {label}")

    resposta = input("\nDeseja remover os duplicados mantendo apenas a primeira ocorrência? (s/n): ").strip().lower()
    if resposta == 's':
        # Carrega todas as linhas do arquivo
        with open(arquivo, encoding='utf-8') as f:
            linhas = f.readlines()
        vistos = set()
        novas_linhas = []
        for line_num, line in enumerate(linhas):
            line = line.strip()
            if line_num == 0 or not line:
                novas_linhas.append(line + '\n')
                continue
            # 1) label: último campo após a última vírgula
            idx_last_comma = line.rfind(',')
            if idx_last_comma == -1:
                novas_linhas.append(line + '\n')
                continue
            label = line[idx_last_comma+1:].strip().replace('"', '')
            restante = line[:idx_last_comma]
            # 2) aspecto: entre a penúltima e última vírgula
            idx_penultimate_comma = restante.rfind(',')
            if idx_penultimate_comma == -1:
                novas_linhas.append(line + '\n')
                continue
            aspecto = restante[idx_penultimate_comma+1:].strip().replace('"', '')
            frase = restante[:idx_penultimate_comma].strip().replace('"', '')
            key = (frase.lower(), aspecto, label)
            if label in ('0', '1'):
                if key in vistos:
                    continue  # pula duplicado
                vistos.add(key)
            # Garante aspas nos campos de texto
            nova_linha = f'"{frase}","{aspecto}",{label}\n'
            novas_linhas.append(nova_linha)
        # Salva o arquivo sem duplicados
        with open(arquivo, 'w', encoding='utf-8') as f:
            f.writelines(novas_linhas)
        print("Duplicados removidos. O arquivo foi atualizado.")
    else:
        print("Nenhuma alteração feita no arquivo.")
else:
    print("\nNão há feedbacks idênticos classificados com o mesmo aspecto e mesmo label.")
