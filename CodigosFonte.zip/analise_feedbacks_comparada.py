import json
import argparse
from sentence_transformers import SentenceTransformer, util
from transformers import BertTokenizer, BertForSequenceClassification
import torch
import os

# Carrega os feedbacks do arquivo JSON
with open('feedbacks.json', 'r', encoding='utf-8') as f:
    feedbacks = json.load(f)

# Carrega os aspectos do arquivo aspectos.json
with open('aspectos.json', 'r', encoding='utf-8') as f:
    aspectos_data = json.load(f)

aspectos_nomes = [a['aspecto'] for a in aspectos_data]

parser = argparse.ArgumentParser(description="Comparação de classificação de aspectos: SBERT vs BerTimbau base vs BerTimbau FT.")
parser.add_argument('--limiar', type=float, default=0.1, help='Limiar de probabilidade/similaridade para associação de aspectos (padrão: 0.1)')
args = parser.parse_args()
limiar_prob = args.limiar

print(f"Usando limiar de probabilidade/similaridade: {limiar_prob}\n")

# SBERT para embeddings
sbert_model = SentenceTransformer('sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2')

# Modelos BerTimbau
bertimbau_model_dir = "FT_BT_ClassificaAspectos"
bertimbau_tokenizer = BertTokenizer.from_pretrained(bertimbau_model_dir)
bertimbau_model = BertForSequenceClassification.from_pretrained(bertimbau_model_dir)
bertimbau_model.eval()

# BerTimbau base (sem fine-tuning)
bertimbau_base_model_dir = "neuralmind/bert-base-portuguese-cased"
bertimbau_base_tokenizer = BertTokenizer.from_pretrained(bertimbau_base_model_dir)
bertimbau_base_model = BertForSequenceClassification.from_pretrained(bertimbau_base_model_dir, num_labels=2)
bertimbau_base_model.eval()

# Função de classificação com SBERT
def classifica_aspectos_sbert(feedback, aspectos_data, limiar):
    aspectos_textos = []
    for asp in aspectos_data:
        texto = asp['aspecto']
        if asp.get('definicao'):
            texto += ". " + asp['definicao']
        if asp.get('sinonimos'):
            texto += ". Sinônimos: " + ", ".join(asp['sinonimos'])
        aspectos_textos.append(texto)
    emb_aspectos = sbert_model.encode(aspectos_textos, convert_to_tensor=True)
    emb_feedback = sbert_model.encode(feedback, convert_to_tensor=True)
    sims = util.cos_sim(emb_feedback, emb_aspectos)[0].cpu().numpy()
    aspectos_detectados = {}
    for idx, sim in enumerate(sims):
        if sim >= limiar:
            aspectos_detectados[aspectos_data[idx]['aspecto']] = sim
    return aspectos_detectados

# Função de classificação com BerTimbau

def classifica_aspectos_bertimbau(model, tokenizer, feedback, aspectos_nomes, limiar):
    aspectos_detectados = {}
    for aspecto in aspectos_nomes:
        texto = feedback + " [ASPECTO] " + aspecto
        inputs = tokenizer(texto, return_tensors="pt", truncation=True, padding="max_length", max_length=128)
        with torch.no_grad():
            outputs = model(**inputs)
            logits = outputs.logits
            probs = torch.softmax(logits, dim=-1).cpu().numpy()[0]
            prob_positivo = probs[1]
        if prob_positivo >= limiar:
            aspectos_detectados[aspecto] = prob_positivo
    return aspectos_detectados

# Função para converter valores numpy.float32 para float
def convert_floats(d):
    # Converte todos os valores numpy.float32 para float recursivamente
    if isinstance(d, dict):
        return {k: convert_floats(v) for k, v in d.items()}
    elif isinstance(d, list):
        return [convert_floats(v) for v in d]
    elif hasattr(d, 'item') and callable(d.item):
        return float(d)
    else:
        return d

# Executa classificação e compara
comparacao_resultados = []
for item in feedbacks:
    feedback = item['feedback']
    print("="*60)
    print(f"ID: {item.get('id')} | Nome: {item.get('nome_pessoa')}")
    print(f"Feedback: {feedback}\n")
    print("SBERT:")
    aspectos_sbert = classifica_aspectos_sbert(feedback, aspectos_data, limiar_prob)
    if aspectos_sbert:
        for aspecto, sim in aspectos_sbert.items():
            print(f"  • {aspecto}: {sim:.2f}")
    else:
        print("  Nenhum aspecto identificado.")
    print("\nBerTimbau base (sem FT):")
    aspectos_bertimbau_base = classifica_aspectos_bertimbau(bertimbau_base_model, bertimbau_base_tokenizer, feedback, aspectos_nomes, limiar_prob)
    if aspectos_bertimbau_base:
        for aspecto, prob in aspectos_bertimbau_base.items():
            print(f"  • {aspecto}: {prob:.2f}")
    else:
        print("  Nenhum aspecto identificado.")
    print("\nBerTimbau FT:")
    aspectos_bertimbau = classifica_aspectos_bertimbau(bertimbau_model, bertimbau_tokenizer, feedback, aspectos_nomes, limiar_prob)
    if aspectos_bertimbau:
        for aspecto, prob in aspectos_bertimbau.items():
            print(f"  • {aspecto}: {prob:.2f}")
    else:
        print("  Nenhum aspecto identificado.")
    print("\nComparação:")
    for aspecto in aspectos_nomes:
        sbert = aspectos_sbert.get(aspecto, None)
        bertimbau_base = aspectos_bertimbau_base.get(aspecto, None)
        bertimbau = aspectos_bertimbau.get(aspecto, None)
        print(f"{aspecto:<30} | SBERT: {sbert if sbert is not None else '         -        '} | BerTimbau base: {bertimbau_base if bertimbau_base is not None else '         -        '} | BerTimbau FT: {bertimbau if bertimbau is not None else '         -        '}")
    # Salva resultado desta comparação
    comparacao_resultados.append({
        "feedback": feedback,
        "SBERT": convert_floats(aspectos_sbert),
        "BerTimbau base": convert_floats(aspectos_bertimbau_base),
        "BerTimbau FT": convert_floats(aspectos_bertimbau)
    })
# Salvar todos os resultados ao final (append sem sobrescrever)
json_path = "comparacao.json"
if os.path.exists(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        try:
            dados_anteriores = json.load(f)
        except Exception:
            dados_anteriores = []
else:
    dados_anteriores = []
dados_anteriores.extend(comparacao_resultados)
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(dados_anteriores, f, ensure_ascii=False, indent=2)
print("="*60)
print("COMPARAÇÃO CONCLUÍDA")
