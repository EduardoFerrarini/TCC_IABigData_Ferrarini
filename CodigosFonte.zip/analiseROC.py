import json
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

# Lista de aspectos a considerar
ASPECTOS = [
    'Colaboração','Comunicação eficaz','Autoconfiança','Autonomia','Pontualidade',
    'Conhecimentos Técnicos','Qualidade das entregas','Adaptabilidade','Gestão do tempo',
    'Proatividade', 'Resiliência', 'Empatia', 'Inovação e Criatividade', 'Organização', 'Relacionamento interpessoal'
]

# Carrega os dados
with open('comparacaoLabel.json', encoding='utf-8') as f:
    dados = json.load(f)

# Função para extrair scores e rótulos binários (presença/ausência de aspecto)
def extrai_scores_labels(dados, modelo):
    scores = []
    labels = []
    for item in dados:
        aspectos_pred = item.get(modelo, {})
        aspectos_true = item.get('label', {})
        for aspecto in ASPECTOS:
            score = aspectos_pred.get(aspecto, 0)
            label = aspectos_true.get(aspecto, 0)
            scores.append(score)
            labels.append(label)
    return np.array(scores), np.array(labels)

modelos = ['SBERT', 'BerTimbau base', 'BerTimbau FT']
plt.figure(figsize=(8,6))
for modelo in modelos:
    scores, labels = extrai_scores_labels(dados, modelo)
    if len(np.unique(labels)) < 2:
        print(f"Não há positivos e negativos suficientes para {modelo}.")
        continue
    fpr, tpr, thresholds = roc_curve(labels, scores)
    roc_auc = auc(fpr, tpr)
    plt.plot(fpr, tpr, label=f'{modelo} (AUC = {roc_auc:.2f})')
    # Melhor limiar
    youden = tpr - fpr
    best_idx = np.argmax(youden)
    best_thresh = thresholds[best_idx]
    print(f"Melhor limiar para {modelo}: {best_thresh:.2f} (Youden J = {youden[best_idx]:.2f})")

plt.plot([0,1], [0,1], 'k--')
plt.xlabel('Falso Positivo Rate')
plt.ylabel('Verdadeiro Positivo Rate')
plt.title('Curva ROC para cada modelo')
plt.legend()
plt.tight_layout()
plt.show()
